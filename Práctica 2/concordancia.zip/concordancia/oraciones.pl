% ______________________________________________________________________________________ %

% -------------------------- PRÁCTICA 2 - CRA ------------------------------------------ %
% ______________________________________________________________________________________ %

% _____________________________ oraciones _______________________________________________ %

oracion1([el,hombre,grande,come,la,manzana,roja]).
oracion2([el,hombre,con,un,tenedor,grande,come,la,manzana,roja]).
oracion3([juan,y,maria,comen,la,manzana,roja,con,un,tenedor,y,un,cuchillo]).
oracion4([tu,hablas,muy,rapidamente]).
oracion5([ella,hace,la,practica,de,juan]).
oracion6([el,canario,de,juan,y,maria,canta]).
oracion7([la,blanca,paloma,alzo,el,vuelo]).
oracion8([esta,muy,lejos,de,madrid]). 
oracion9([soy,lento,de,reflejos]).
oracion10([manana,iremos,a,la,feria,del,comic]). 
oracion11([la,esperanza,de,vida,de,un,nino,depende,de,su,lugar,de,nacimiento]).
oracion12([el,senor,que,vimos,en,la,universidad,era,mi,profesor]).
oracion13([juan,que,es,muy,delicado,come,solamente,manzanas,rojas]).
oracion14([juan,es,moreno,y,maria,es,alta]).
oracion15([juan,recoge,la,mesa,mientras,maria,toma,un,cafe]).
oracion16([compre,un,pantalon,y,una,corbata,negros]).
oracion17([juan,y,hector,comen,patatas,fritas,y,beben,cerveza]).
oracion18([bebimos,y,bailamos,toda,la,noche,mientras,tu,estudiabas]). % 
oracion19([esos,ninos,cantan,y,saltan,y,sonrien,alegres]).
oracion20([creo,que,necesitais,la,ayuda,de,un,profesional]).
oracion21([el,procesador,de,textos,que,es,una,herramienta,muy,potente,sirve,para,escribir,documentos]).
oracion22([el,procesador,de,textos,es,una,herramienta,muy,potente,que,sirve,para,escribir,documentos,pero,es,bastante,lento]).