% ______________________________________________________________________________________ %

% -------------------------- PRÁCTICA 2 - CRA ------------------------------------------ %
% ______________________________________________________________________________________ %

% _________________________________ test _______________________________________________ %

:- consult(gramatica).
:- consult(draw).
:- consult(oraciones).

% ______________________________________________________________________________________ %

% TESTS

test1:- oracion1(Or1), oracion(X, Or1, []), draw(X), nl.
test2:- oracion2(Or2), oracion(X, Or2, []), draw(X), nl.
test3:- oracion3(Or3), oracion(X, Or3, []), draw(X), nl.
test4:- oracion4(Or4), oracion(X, Or4, []), draw(X), nl.
test5:- oracion5(Or5), oracion(X, Or5, []), draw(X), nl.
test6:- oracion6(Or6), oracion(X, Or6, []), draw(X), nl.
test7:- oracion7(Or7), oracion(X, Or7, []), draw(X), nl.
test8:- oracion8(Or8), oracion(X, Or8, []), draw(X), nl.
test9:- oracion9(Or9), oracion(X, Or9, []), draw(X), nl.
test10:- oracion10(Or10), oracion(X, Or10, []), draw(X), nl.
test11:- oracion11(Or11), oracion(X, Or11, []), draw(X), nl.
test12:- oracion12(Or12), oracion(X, Or12, []), draw(X), nl.
test13:- oracion13(Or13), oracion(X, Or13, []), draw(X), nl.
test14:- oracion14(Or14), oracion(X, Or14, []), draw(X), nl.
test15:- oracion15(Or15), oracion(X, Or15, []), draw(X), nl.
test16:- oracion16(Or16), oracion(X, Or16, []), draw(X), nl.
test17:- oracion17(Or17), oracion(X, Or17, []), draw(X), nl.
test18:- oracion18(Or18), oracion(X, Or18, []), draw(X), nl.
test19:- oracion19(Or19), oracion(X, Or19, []), draw(X), nl.
test20:- oracion20(Or20), oracion(X, Or20, []), draw(X), nl.
test21:- oracion21(Or21), oracion(X, Or21, []), draw(X), nl.
test22:- oracion22(Or22), oracion(X, Or22, []), draw(X), nl.